#ifndef  _PWM_H
#define  _PWM_H

#include "sys.h" 
void Pwm_Init(u16 Psc,u16 Per);

#endif
