#include "motor.h"

//PA2345
//�����ʼ��
void Motor_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;	
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
}


//���Ʒ���
void Limit(int *motorA,int *motorB)
{
	if(*motorA>PWM_MAX)*motorA=PWM_MAX;
	if(*motorA<PWM_MIN)*motorA=PWM_MAX;
	if(*motorB>PWM_MAX)*motorB=PWM_MAX;
	if(*motorB<PWM_MIN)*motorB=PWM_MAX;
}


//ȡ����ֵ����
int GFP_abs(int p)
{
	int q;
	q = p>0?p:(-p);
	return q;
}

//��PID��ֵװ�ص������
void Load(int motor1,int motor2)
{
	if(motor1>0)Ain1=1,Ain2=0;
	else 				Ain1=0,Ain2=1;
	TIM_SetCompare1(TIM1,GFP_abs(motor1));
	
	if(motor2>0)Bin1=1,Bin2=0;
	else 				Bin1=0,Bin2=1;	
	TIM_SetCompare4(TIM1,GFP_abs(motor2));
	
	
}




