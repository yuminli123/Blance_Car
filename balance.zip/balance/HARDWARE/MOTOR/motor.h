#ifndef  _MOTOR_H
#define  _MOTOR_H

#include "sys.h" 
//λ������
#define Ain1 PAout(2)
#define Ain2 PAout(3)
#define Bin1 PAout(4)
#define Bin2 PAout(5)

void Motor_Init(void);
void Limit(int *motorA,int *motorB);
int GFP_abs(int p);
void Load(int motor1,int motor2);

#endif

